from run_es_host_pc import send_command

if __name__ == '__main__':
    while True:
        command = raw_input("es> ")
        if command == "quit":
            break
        send_command(command)
