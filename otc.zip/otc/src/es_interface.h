/*
 * es_interface.h
 *
 *  Created on: Jul 15, 2014
 *      Author: ddboline
 */

#ifndef ES_INTERFACE_H_
#define ES_INTERFACE_H_

int es_interface(int s, const void *data, size_t size);

#endif /* ES_INTERFACE_H_ */
