eyescanOTC
==========

Step by Step Instructions:
    0. Turn on Crate, make sure JTAG connector is attached, Optical Fiber plugged in, OTC is powered, etc.
    1. Locate the directory called eyescanOTC_20140907 (should be in c:\Users\LArTest\Desktop\)
    2. Open Xilinx SDK 2013.3, choose c:\Users\LArTest\Desktop\eyescanOTC_20140907 as workspace directory
    3. Probably helpful to go to Project->Clean to rebuild project
    4. Program FPGA: Xilinx Tools->Program FPGA
        * Check that correct Bitstream and BMM File is used:
            C:\Users\LArTest\Desktop\eyescanOTC_20140907\hw_platform_0\design_1_wrapper_6g4_OK_ch0_20150114.bit
            C:\Users\LArTest\Desktop\eyescanOTC_20140907\hw_platform_0\design_1_wrapper_bd_6g4_OK_ch0_20150114.bmm
        * Other combinations from the same directory will probably work
    5. Run the project: Run->Run
    6. Open "Git Bash" program.
    7. cd into py_scripts directory:
        * cd /c/Users/LArTest/Desktop/eyescanOTC_20140907/otc/Debug/py_scripts
    8. Run the run_eyescan.py script, specifying your own name and whether you wish to run a 1d bathtub or 2d eyescan
        * python run_eyescan.py esrun <label> <1|2>
    9. Run the run_eyescan.py script a second time, this time with the esplot command, specifying the tarball (has the form <label>_<date>.tar.gz):
        * python run_eyescan.py esplot <tar.gz file> <1|2>
    10. If everything runs successfully, a summary pdf will appear in the directory:
        C:\Users\LArTest\Desktop\eyescanOTC_20140907\otc\Debug\pdf_files\

OTC Test Suite
==============

Step by Step Instructions:
    1. Locate the directory called OpticalTestCard_20150112 (should be in c:\Users\LArTest\Desktop\)
    2. Open Xilinx SDK 2013.3, choose c:\Users\LArTest\Desktop\OpticalTestCard_20150112 as workspace directory
    3. Probably helpful to go to Project->Clean to rebuild project
    4. Program FPGA: Xilinx Tools->Program FPGA
        * Check that correct Bitstream and BMM File is used:
            C:\Users\LArTest\Desktop\OpticalTestCard_20150112\hw_platform_0\design_1_wrapper.bit
            C:\Users\LArTest\Desktop\OpticalTestCard_20150112\hw_platform_0\design_1_wrapper_bd.bmm
        * Other combinations from the same directory will probably work
    5. Run the project: Run->Run
    6. Open a web browser, navigate to:
        http://192.168.1.99
