/*
 * SysStatus.c
 *
 *  Created on: Feb 21, 2014
 *      Author: hobbs
 */

#define SYSSTATUS_C
#include "SysStatus.h"

struct procInfo procStatus;
struct ethInfo  ethStatus;
